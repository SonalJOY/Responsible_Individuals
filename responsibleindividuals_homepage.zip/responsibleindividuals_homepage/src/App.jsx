import "./index.css";

const impactAreas = [
  {
    icon: "🎓",
    title: "Education",
    text: "Creating opportunities for learning, growth and skill development."
  },
  {
    icon: "🌱",
    title: "Environment",
    text: "Encouraging sustainable practices and protecting our surroundings."
  },
  {
    icon: "🤝",
    title: "Community",
    text: "Working with communities to create meaningful local solutions."
  },
  {
    icon: "❤️",
    title: "Health & Wellbeing",
    text: "Supporting healthier and more resilient communities."
  },
  {
    icon: "💼",
    title: "Livelihood",
    text: "Helping individuals build skills and opportunities for sustainable livelihoods."
  },
  {
    icon: "🌍",
    title: "Civic Responsibility",
    text: "Encouraging citizens to participate and contribute to society."
  }
];

const projects = [
  {
    image:
      "https://images.unsplash.com/photo-1497250681960-ef046c08a56e?auto=format&fit=crop&w=1000&q=80",
    category: "Environment",
    title: "Community Green Initiative",
    description:
      "Bringing communities together to create greener and more sustainable spaces."
  },
  {
    image:
      "https://images.unsplash.com/photo-1509099836639-18ba1795216d?auto=format&fit=crop&w=1000&q=80",
    category: "Education",
    title: "Learning for Tomorrow",
    description:
      "Supporting learning opportunities and empowering young people through education."
  },
  {
    image:
      "https://images.unsplash.com/photo-1559027615-cd4628902d4a?auto=format&fit=crop&w=1000&q=80",
    category: "Community",
    title: "Stronger Together",
    description:
      "Connecting volunteers and communities to address local needs together."
  }
];

const stories = [
  {
    image:
      "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=1000&q=80",
    title: "Small actions. Meaningful change.",
    text:
      "When people come together with a shared purpose, even small contributions can create lasting change."
  },
  {
    image:
      "https://images.unsplash.com/photo-1531206715517-5c0ba140b2b8?auto=format&fit=crop&w=1000&q=80",
    title: "Communities leading the way",
    text:
      "Our work begins by listening to communities and building solutions with them."
  }
];

function App() {
  return (
    <div className="site">

      {/* ================= NAVBAR ================= */}

      <header className="navbar">
        <div className="nav-container">

          <a href="#" className="logo">
            <div className="logo-mark">
              <span>RI</span>
            </div>

            <div className="logo-text">
              <strong>Responsible</strong>
              <small>Individuals</small>
            </div>
          </a>

          <nav className="nav-links">
            <a href="#about">About</a>
            <a href="#work">Our Work</a>
            <a href="#impact">Impact</a>
            <a href="#stories">Stories</a>
            <a href="#events">Events</a>
            <a href="#contact">Contact</a>
          </nav>

          <a href="#involved" className="nav-button">
            Get Involved
          </a>

        </div>
      </header>


      {/* ================= HERO ================= */}

      <section className="hero">

        <div className="hero-content">

          <div className="hero-label">
            BUILDING RESPONSIBLE COMMUNITIES
          </div>

          <h1>
            Together, we can
            <span> create lasting change.</span>
          </h1>

          <p>
            Empowering citizens, communities and partners to create
            meaningful and sustainable impact.
          </p>

          <div className="hero-buttons">

            <a href="#work" className="button primary">
              Explore Our Work
              <span>→</span>
            </a>

            <a href="#involved" className="button secondary">
              Get Involved
            </a>

          </div>

          <a href="#impact" className="discover">
            <span>↓</span>
            Discover our impact
          </a>

        </div>

        <div className="hero-vertical">
          <span>01</span>
          <i></i>
          <span>COMMUNITY • RESPONSIBILITY • IMPACT</span>
        </div>

      </section>


      {/* ================= ABOUT ================= */}

      <section className="about-section" id="about">

        <div className="section-label">
          <span>01</span>
          WHO WE ARE
        </div>

        <div className="about-grid">

          <h2>
            Turning responsible
            <em> action</em> into
            <br />
            community impact.
          </h2>

          <div className="about-text">

            <p>
              Responsible Individuals brings together people, communities,
              volunteers and partners to work towards meaningful social
              impact.
            </p>

            <p>
              We believe sustainable change begins when individuals take
              responsibility and communities work together.
            </p>

            <a href="#" className="text-link">
              Learn more about us →
            </a>

          </div>

        </div>

      </section>


      {/* ================= IMPACT ================= */}

      <section className="impact-section" id="impact">

        <div className="impact-top">

          <div>

            <div className="eyebrow">
              OUR IMPACT
            </div>

            <h2>
              Change that can be
              <br />
              <span>seen and measured.</span>
            </h2>

          </div>

          <p>
            We believe meaningful social work should create measurable
            outcomes that communities can experience and sustain.
          </p>

        </div>

        <div className="stats">

          <div className="stat">
            <strong>50+</strong>
            <span>Projects</span>
          </div>

          <div className="stat">
            <strong>120+</strong>
            <span>Communities</span>
          </div>

          <div className="stat">
            <strong>10K+</strong>
            <span>People Reached</span>
          </div>

          <div className="stat">
            <strong>2.5K+</strong>
            <span>Volunteers</span>
          </div>

        </div>

      </section>


      {/* ================= FOCUS AREAS ================= */}

      <section className="focus-section">

        <div className="section-heading">

          <div>

            <div className="eyebrow">
              WHERE WE WORK
            </div>

            <h2>Our focus areas</h2>

          </div>

          <p>
            Our work responds to community needs across multiple areas,
            creating opportunities for people to participate and contribute.
          </p>

        </div>

        <div className="focus-grid">

          {impactAreas.map((area, index) => (

            <div className="focus-card" key={area.title}>

              <div className="focus-icon">
                {area.icon}
              </div>

              <span className="card-number">
                0{index + 1}
              </span>

              <h3>{area.title}</h3>

              <p>{area.text}</p>

              <a href="#">
                Explore area →
              </a>

            </div>

          ))}

        </div>

      </section>


      {/* ================= PROJECTS ================= */}

      <section className="projects-section" id="work">

        <div className="section-heading">

          <div>

            <div className="eyebrow">
              WHAT WE DO
            </div>

            <h2>Featured projects</h2>

          </div>

          <a href="#" className="outline-button">
            View all projects →
          </a>

        </div>

        <div className="projects-grid">

          {projects.map((project) => (

            <article className="project-card" key={project.title}>

              <div className="project-image">

                <img
                  src={project.image}
                  alt={project.title}
                />

                <span>
                  {project.category}
                </span>

              </div>

              <div className="project-content">

                <h3>{project.title}</h3>

                <p>{project.description}</p>

                <a href="#">
                  View project →
                </a>

              </div>

            </article>

          ))}

        </div>

      </section>


      {/* ================= APPROACH ================= */}

      <section className="approach-section">

        <div className="approach-left">

          <div className="eyebrow">
            OUR APPROACH
          </div>

          <h2>
            From community need
            <br />
            to lasting impact.
          </h2>

          <p>
            We work with communities and partners through a structured
            process designed to create sustainable solutions.
          </p>

          <a href="#" className="button approach-button">
            Our Approach →
          </a>

        </div>

        <div className="process">

          <div className="process-item">

            <span>01</span>

            <div>
              <h3>Identify the need</h3>
              <p>
                Understand community challenges and priorities.
              </p>
            </div>

          </div>

          <div className="process-item">

            <span>02</span>

            <div>
              <h3>Engage the community</h3>
              <p>
                Bring people and stakeholders into the process.
              </p>
            </div>

          </div>

          <div className="process-item">

            <span>03</span>

            <div>
              <h3>Implement solutions</h3>
              <p>
                Turn ideas into practical community initiatives.
              </p>
            </div>

          </div>

          <div className="process-item">

            <span>04</span>

            <div>
              <h3>Measure the impact</h3>
              <p>
                Track outcomes and learn what creates lasting change.
              </p>
            </div>

          </div>

        </div>

      </section>


      {/* ================= STORIES ================= */}

      <section className="stories-section" id="stories">

        <div className="section-heading">

          <div>

            <div className="eyebrow">
              STORIES OF CHANGE
            </div>

            <h2>
              Behind every number
              <br />
              is a human story.
            </h2>

          </div>

          <a href="#" className="outline-button">
            Read all stories →
          </a>

        </div>

        <div className="stories-grid">

          {stories.map((story) => (

            <article className="story-card" key={story.title}>

              <img src={story.image} alt={story.title} />

              <div className="story-overlay">

                <span>STORY OF CHANGE</span>

                <h3>{story.title}</h3>

                <p>{story.text}</p>

                <a href="#">
                  Read story →
                </a>

              </div>

            </article>

          ))}

        </div>

      </section>


      {/* ================= GET INVOLVED ================= */}

      <section className="involved-section" id="involved">

        <div className="involved-content">

          <div className="eyebrow">
            BE PART OF THE CHANGE
          </div>

          <h2>
            There is a role for
            <br />
            <span>everyone.</span>
          </h2>

          <p>
            Whether you volunteer your time, support a cause, attend an
            event or partner with us, your contribution matters.
          </p>

        </div>

        <div className="involved-grid">

          <a href="#" className="involve-card">

            <span>01</span>

            <strong>Volunteer</strong>

            <small>
              Give your time & skills →
            </small>

          </a>

          <a href="#" className="involve-card">

            <span>02</span>

            <strong>Donate</strong>

            <small>
              Support a cause →
            </small>

          </a>

          <a href="#" className="involve-card">

            <span>03</span>

            <strong>Partner</strong>

            <small>
              Create impact together →
            </small>

          </a>

        </div>

      </section>


      {/* ================= EVENTS ================= */}

      <section className="events-section" id="events">

        <div className="event-heading">

          <div>

            <div className="eyebrow">
              JOIN US
            </div>

            <h2>Upcoming events</h2>

          </div>

          <a href="#" className="text-link">
            View all events →
          </a>

        </div>

        <div className="event-list">

          <div className="event">

            <div className="event-date">
              <strong>18</strong>
              <span>OCT</span>
            </div>

            <div className="event-info">

              <span>COMMUNITY</span>

              <h3>
                Community Action Day
              </h3>

              <p>
                Bengaluru • 9:00 AM
              </p>

            </div>

            <a href="#">→</a>

          </div>

          <div className="event">

            <div className="event-date">
              <strong>26</strong>
              <span>OCT</span>
            </div>

            <div className="event-info">

              <span>VOLUNTEERING</span>

              <h3>
                Volunteer Orientation
              </h3>

              <p>
                Bengaluru • 10:00 AM
              </p>

            </div>

            <a href="#">→</a>

          </div>

        </div>

      </section>


      {/* ================= FINAL CTA ================= */}

      <section className="final-cta">

        <div className="final-content">

          <div className="eyebrow">
            START WITH ONE ACTION
          </div>

          <h2>
            What will you do
            <br />
            for your community?
          </h2>

          <p>
            Change begins with responsible individuals choosing to act.
          </p>

          <div className="cta-buttons">

            <a href="#" className="button primary">
              Become a Volunteer →
            </a>

            <a href="#" className="button secondary">
              Support Our Work
            </a>

          </div>

        </div>

      </section>


      {/* ================= FOOTER ================= */}

      <footer id="contact">

        <div className="footer-main">

          <div className="footer-brand">

            <a href="#" className="logo">

              <div className="logo-mark">
                <span>RI</span>
              </div>

              <div className="logo-text">

                <strong>Responsible</strong>

                <small>
                  Individuals
                </small>

              </div>

            </a>

            <p>
              Building responsible communities and creating sustainable
              impact through collective action.
            </p>

          </div>


          <div className="footer-column">

            <h4>Explore</h4>

            <a href="#">About</a>
            <a href="#">Our Work</a>
            <a href="#">Impact</a>
            <a href="#">Stories</a>

          </div>


          <div className="footer-column">

            <h4>Get Involved</h4>

            <a href="#">Volunteer</a>
            <a href="#">Donate</a>
            <a href="#">Partner</a>
            <a href="#">Events</a>

          </div>


          <div className="footer-column">

            <h4>Connect</h4>

            <a href="#">Contact</a>
            <a href="#">Resources</a>
            <a href="#">Careers</a>
            <a href="#">Gallery</a>

          </div>

        </div>


        <div className="footer-bottom">

          <span>
            © 2026 Responsible Individuals
          </span>

          <span>
            Service Learning Project
          </span>

          <span>
            Building impact together.
          </span>

        </div>

      </footer>

    </div>
  );
}

export default App;